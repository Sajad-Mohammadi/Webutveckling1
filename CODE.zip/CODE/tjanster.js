Vue.createApp({
    data() {
      return {
        total: 0,
        counter: 0
        };
      },
      methods: {
        clear(i) {
          
        }

      
    }
  }).mount('#app');